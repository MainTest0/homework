package Ex09;

public enum EnemyWay {

	LEFT,RIGHT
	
}
