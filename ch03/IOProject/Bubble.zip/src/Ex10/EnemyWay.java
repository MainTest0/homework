package Ex10;

public enum EnemyWay {

	LEFT,RIGHT
	
}
