package Ex11;

public enum EnemyWay {

	LEFT,RIGHT
	
}
