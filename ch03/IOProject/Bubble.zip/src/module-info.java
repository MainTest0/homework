module Bubble {
	requires java.desktop;
}